import React from 'react'

const KycUpload = () => {
  return (
    <div>KycUpload</div>
  )
}

export default KycUpload